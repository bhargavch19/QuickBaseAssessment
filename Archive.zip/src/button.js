import React from "react";
export function Button(props) {
  return <button {...props}>{props.children}</button>;
}
