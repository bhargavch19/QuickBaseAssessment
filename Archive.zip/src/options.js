export const choiceOptions = [
  "Asia",
  "Australia",
  "Western Europe",
  "North America",
  "Eastern Europe",
  "Latin America",
  "Middle East and Africa"
];