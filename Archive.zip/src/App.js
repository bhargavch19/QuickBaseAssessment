import React from "react";
import "./styles.css";
import FieldBuild from "./FieldBuild";

export default function App() {
  return (
    <div className="App">
      <h1>Reactjs validation</h1>
      <FieldBuild />
    </div>
  );
}
