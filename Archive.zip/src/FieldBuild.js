import React from "react";
import { saveField } from "./fieldService";
import { Button } from "./button";
import { choiceOptions } from "./options"

class FieldBuild extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: {
        sales: "",
        required: false,
        defaultValue: "",
        choices: [],
        order: ""
      },
      errors: {
        sales: "",
        required: "",
        defaultValue: "",
        choices: ""
      },
      isSubmitted: false
    };
  }
  componentDidMount = () => {
    const form = window.sessionStorage.getItem("form");
    if (form) {
      this.setState({ ...this.state, fields: JSON.parse(form) });
    }
    
  };
  validate = (name, value) => {
    switch (name) {
      case "sales":
        if (!value || value.trim() === "") {
          return "First name is Required";
        } else {
          return "";
        }
      case "required":
        if (!value) {
          return "type is Required";
        } else {
          return "";
        }
      case "defaultValue":
        if (!value || value.trim() === "") {
          return "defaultValue is Required";
        } else {
          return "";
        }
      case "choices":
        if (!value.length) {
          return "Choice is Required";
        } else {
          return "";
        }
      default: {
        return "";
      }
    }
  };

  handleUserInput = (e) => {
    const data = {
      errors: {
        ...this.state.errors,
        [e.target.name]: this.validate(e.target.name, e.target.value)
      },
      fields: {
        ...this.state.fields,
        [e.target.name]: e.target.value
      }
    };
    this.setState(data);
    window.sessionStorage.setItem("form", JSON.stringify(data.fields));
  };
  handleType = (e) => {
    this.setState({
      errors: {
        ...this.state.errors,
        [e.target.name]: this.validate(e.target.name, e.target.checked)
      },
      fields: {
        ...this.state.fields,
        [e.target.name]: e.target.checked
      }
    });
  };

  handleSubmit = (e) => {
    const { fields } = this.state;
    e.preventDefault();
    let validationErrors = {};
    Object.keys(fields).forEach((name) => {
      const error = this.validate(name, fields[name]);
      if (error && error.length > 0) {
        validationErrors[name] = error;
      }
    });
    if (Object.keys(validationErrors).length > 0) {
      this.setState({ errors: validationErrors });
      return;
    }
    if (
      fields.sales &&
      fields.required &&
      fields.defaultValue &&
      fields.choices.length
    ) {
      this.setState({ ...this.state, isSubmitted: true });
      console.log("----data----", this.state.fields);
      saveField(fields, (res) => {
        if (window.sessionStorage.getItem("form"))
          window.sessionStorage.removeItem("form");
        console.log("----res----", res);
        this.setState({ ...this.state, isSubmitted: false });
      });
    }
  };
  handleMultiSelect = (select) => {
    const { name } = select;
    console.log("name", name);
    const options = [...select.options]
      .filter((option) => option.selected)
      .map((option) => option.value);
    if (options.length > 50) {
    } else {
      const data = {
        errors: {
          ...this.state.errors,
          [name]: this.validate(name, options.length ? select.options : "")
        },
        fields: {
          ...this.state.fields,
          [name]: [...select.options]
            .filter((option) => option.selected)
            .map((option) => option.value)
            .sort()
        }
      };
      this.setState(data);
      window.sessionStorage.setItem("form", JSON.stringify(data.fields));
    }
  };

  render() {
    const { fields, errors } = this.state;
    return (
      <div>
        <pre>{JSON.stringify(this.state.fields, null, 2)}</pre>
        <div className="border">
          <div className="box-header">Field Builder</div>
          <div className="box-body">
            <div className="form-group">
              <div>
                <label>Label</label>
                <div className="sc">
                  <input
                    type="text"
                    name="sales"
                    value={fields.sales}
                    onChange={(event) => this.handleUserInput(event)}
                    placeholder="Sales Region"
                  />
                  <div>
                    <span className="text-danger">{errors.sales}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="form-group">
              <label>Type</label>
              <div className="s-ection check sc">
                Multi-select &nbsp;
                <input
                  type="checkbox"
                  name="required"
                  checked={fields.required}
                  onChange={(event) => this.handleType(event)}
                />
                &nbsp;&nbsp;A Value is required
                <div>
                  <span className="text-danger">{errors.required}</span>
                </div>
              </div>
            </div>
            <div className="form-group">
              <label>Default Value</label>
              <div className="sc">
                <input
                  name="defaultValue"
                  type="text"
                  value={fields.defaultValue}
                  onChange={(event) => this.handleUserInput(event)}
                  placeholder="Defaut value"
                />
                <div>
                  <span className="text-danger">{errors.defaultValue}</span>
                </div>
              </div>
            </div>
            <div className="form-group">
              <label>Choices</label>
              <div className="s-ection sc">
                <select
                  multiple
                  className="select multi"
                  name="choices"
                  value={fields.choices}
                  onChange={(event) => this.handleMultiSelect(event.target)}
                >
                  {choiceOptions.map((x, i) => (
                    <option key={i} value={x}>
                      {x}
                    </option>
                  ))}
                </select>

                <div>
                  <span className="text-danger">{errors.choices}</span>
                </div>
              </div>
            </div>
            <div className="form-group">
              <label>Order</label>
              <div className="s-ection sc">
                <select
                  className="select single"
                  value={fields.order}
                  onChange={(event) => this.handleUserInput(event)}
                >
                  {fields.choices.map((x, i) => (
                    <option key={i} value={x}>
                      {x}
                    </option>
                  ))}
                </select>

                <div>
                  <span className="text-danger">{errors.order}</span>
                </div>
              </div>
            </div>
            <div className="form-group text-center">
              <Button
                type="button"
                className={`btn btn-primary pointer ${
                  this.state.isSubmitted ? "spin" : ""
                }`}
                onClick={this.handleSubmit}
              >
                <span className="spinner"></span> Save Changes
              </Button>
              <span>Or</span>
              <Button
                type="button"
                className="btn btn-default pointer"
                onClick={() => {
                  this.setState({
                    ...this.state,
                    fields: {
                      sales: "",
                      required: false,
                      defaultValue: "",
                      choices: [],
                      order: ""
                    }
                  });
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default FieldBuild;
