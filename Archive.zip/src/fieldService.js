export const saveField = (fields, callback) => {
  try {
    fetch("http://www.mocky.io/v2/566061f21200008e3aabd919", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(fields)
    })
      .then((x) => x.json())
      .then((res) => {
        if (callback) callback(res);
      });
  } catch (err) {
    if (callback) callback(err);
  }
};
